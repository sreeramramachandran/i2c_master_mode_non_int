/*
 * 12c_master.h
 *
 *  Created on: May 8, 2026
 *      Author: microairf97
 */

#ifndef INC_I2C_MASTER_H_
#define INC_I2C_MASTER_H_

void write_data(uint8_t *pdata,uint8_t len);

#endif /* INC_I2C_MASTER_H_ */
