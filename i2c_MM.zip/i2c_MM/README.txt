-> This is the basic setup for i2c master, 
-> sda to PB9 and scl to PB8
-> We need to give one pull up resistor in each sda and scl lines 
-> the resistor is having 4.7k ohm
-> the resistor will pull up the line to 3.3v 
-> we need to make the gpio for sda and scl as pullup with very high speed freq

PB8 ----+---- SCL
        |
       4.7k
        |
      3.3V

PB9 ----+---- SDA
        |
       4.7k
        |
      3.3V